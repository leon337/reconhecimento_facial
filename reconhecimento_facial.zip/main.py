#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
from pathlib import Path
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from app.models import db

def create_app():
    # 1) Inicializa o Flask e configura pasta estática
    app = Flask(__name__, static_folder='static')

    # 2) Chave secreta para habilitar session() e flash()
    #     • Em produção, defina EXPORT SECRET_KEY na sua shell
    #     • Em dev, usa valor default (mas troque para algo aleatório!)
    app.config['SECRET_KEY'] = os.environ.get(
        'SECRET_KEY',
        'a9f8d76b2c3e4f1a0b7c9d8e6f5a4b3c'  # ❗️ troque por algo difícil de adivinhar
    )

    # 3) Configura banco SQLite dentro da pasta instance
    instance_path = os.path.join(app.root_path, 'instance')
    os.makedirs(instance_path, exist_ok=True)
    app.config['SQLALCHEMY_DATABASE_URI'] = f"sqlite:///{os.path.join(instance_path, 'ponto.db')}"
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

    # 4) Pasta de uploads
    upload_folder = os.path.join(app.static_folder, 'uploads')
    os.makedirs(upload_folder, exist_ok=True)
    app.config['UPLOAD_FOLDER'] = upload_folder

    # 5) Inicializa o SQLAlchemy
    db.init_app(app)
    with app.app_context():
        db.create_all()

    # 6) Registra os blueprints de rotas
    from app.routes      import bp as routes_bp
    from app.admin.routes import bp as admin_bp
    app.register_blueprint(routes_bp)
    app.register_blueprint(admin_bp, url_prefix='/admin')

    return app

if __name__ == '__main__':
    # Cria e sobe o servidor
    app = create_app()
    app.run(debug=True, host='0.0.0.0', port=5000)
